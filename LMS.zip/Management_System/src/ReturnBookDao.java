import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ReturnBookDao {
	public static int delete(String callno,String studentid){
		int status=0;
		try{
			Connection con=DB.getConnection();
			
			status=updatebook(callno);//updating quantity and issue
			
			if(status>0){
			PreparedStatement ps=con.prepareStatement("delete from `issuebooks` where `Book ID`=? and `Student ID`=?");
			ps.setString(1,callno);
			ps.setString(2,studentid);
			status=ps.executeUpdate();
			}
			
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	public static int update(String callno,String studentid, String stat, String issue){
		int status=0;
		try{
			Connection con=DB.getConnection();

			PreparedStatement ps=con.prepareStatement("update `history` set `Date Returned`=now(),`Status`=? where `Book ID`=? and `Student ID`=? and `Date Issued`=?");
			ps.setString(1,stat);
			ps.setString(2,callno);
			ps.setString(3,studentid);
			ps.setString(4,issue);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	public static int updatebook(String callno){
		int status=0;
		int quantity=0,issued=0;
		try{
			Connection con=DB.getConnection();
			
			PreparedStatement ps=con.prepareStatement("select `Available`, `Transacted` from `books` where `Book ID`=?");
			ps.setString(1,callno);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				quantity=rs.getInt("Available");
				issued=rs.getInt("Transacted");
			}
			
			if(issued>0){
			PreparedStatement ps2=con.prepareStatement("update `books` set  `Available`=?, `Transacted`=? where `Book ID`=?");
			ps2.setInt(1,quantity+1);
			ps2.setInt(2,issued-1);
			ps2.setString(3,callno);
			
			status=ps2.executeUpdate();
			}
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
}
