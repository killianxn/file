import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class func {
	public static int countData (String tableName) {
		int total = 0;
		ResultSet rs;
		Statement st;
		
		try {
			st = DB.getConnection().createStatement();
			rs = st.executeQuery("select count(*) as total from `"+tableName+"`");
			
			if (rs.next()) {
				total = rs.getInt("total");
			}
		} catch (SQLException ex) {
			Logger.getLogger(func.class.getName()).log(Level.SEVERE,null,ex);
		}
		return total;
	}
	
	public static int countOverdue (String tableName) {
		int overdue_count = 0;
		ResultSet rs;
		Statement st;
		
		try {
			st = DB.getConnection().createStatement();
			rs = st.executeQuery("SELECT COUNT(*) AS overdue_count FROM `"+tableName+"` WHERE `Status`='Overdue'");
			
			if (rs.next()) {
				overdue_count = rs.getInt("overdue_count");
			}
		} catch (SQLException e) {
			Logger.getLogger(func.class.getName()).log(Level.SEVERE,null,e);
		}	
		return overdue_count;
}
	
}