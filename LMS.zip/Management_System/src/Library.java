import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Library extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static Library frame;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame= new Library();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Library() {
		setTitle("AutoLib");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 840, 441);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setLayout(null);
		
		//imports picture
		ImageIcon image2= new ImageIcon(getClass().getResource("logosmol.png"));
		
		ImageIcon image3= new ImageIcon(getClass().getResource("outline.png"));
		
		setIconImage(image3.getImage());
		
		//set icon in jlabel logo of autolib
		JLabel lblNewLabel_2 = new JLabel(image2);
		lblNewLabel_2.setBounds(556, 42, 306, 232);
		contentPane.add(lblNewLabel_2);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 51));
		panel.setBounds(0, 0, 824, 149);
		contentPane.add(panel);
		panel.setLayout(null);
		
		contentPane.add(panel);
		
		JLabel lblNewLabel_6 = new JLabel("Mabiga, Mabalacat City Pampanga");
		lblNewLabel_6.setBounds(29, 69, 344, 30);
		panel.add(lblNewLabel_6);
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setFont(new Font("Verdana", Font.PLAIN, 20));
		
		JLabel lblNewLabel_5 = new JLabel("CHILDREN OF FATIMA SCHOOL, INC.");
		lblNewLabel_5.setBounds(29, 31, 557, 42);
		panel.add(lblNewLabel_5);
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBackground(new Color(255, 255, 255));
		lblNewLabel_5.setFont(new Font("Algerian", Font.PLAIN, 35));
		
		JButton btnAdminLogin = new JButton("Admin Login");
		btnAdminLogin.setBounds(27, 247, 300, 89);
		contentPane.add(btnAdminLogin);
		btnAdminLogin.setFont(new Font("Century Gothic", Font.BOLD, 20));
		btnAdminLogin.setForeground(new Color(255, 255, 255));
		btnAdminLogin.setBackground(new Color(0, 0, 51));
		
		JButton btnLibrarianLogin = new JButton("Librarian Login");
		btnLibrarianLogin.setBounds(351, 247, 300, 89);
		contentPane.add(btnLibrarianLogin);
		btnLibrarianLogin.setFont(new Font("Century Gothic", Font.BOLD, 20));
		btnLibrarianLogin.setForeground(new Color(255, 255, 255));
		btnLibrarianLogin.setBackground(new Color(0, 0, 51));
		
		
		JLabel lblLibraryManagement = new JLabel("AutoLib");
		lblLibraryManagement.setBounds(27, 160, 155, 40);
		contentPane.add(lblLibraryManagement);
		lblLibraryManagement.setHorizontalAlignment(SwingConstants.CENTER);
		lblLibraryManagement.setFont(new Font("Century Gothic", Font.BOLD, 40));
		lblLibraryManagement.setForeground(new Color(0, 0, 51));
		
		JLabel lblNewLabel = new JLabel("Library Management System");
		lblNewLabel.setForeground(new Color(0, 0, 51));
		lblNewLabel.setFont(new Font("Century Gothic", Font.PLAIN, 20));
		lblNewLabel.setBounds(185, 170, 277, 23);
		contentPane.add(lblNewLabel);
		
		//btn librarian prompt
		btnLibrarianLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				LibrarianLogin.main(new String[]{});
				frame.dispose();
			}
		});
		
		//btn admin prompt
		btnAdminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminLogin.main(new String[]{});
				frame.dispose();
			}
		});
		
	}
}
