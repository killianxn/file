import java.sql.Connection;
import java.sql.PreparedStatement;
public class LogSheetDao {

	
	public static int save(String name,String section){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into `logs`(`Student Name`, `Grade & Section`) values(?,?)");
			ps.setString(1,name);
			ps.setString(2,section);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	public static int update(String name, String section) {
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("update `logs` set `Time Out`=now() where `Student Name`=? and `Grade & Section`=?");
			ps.setString(1,name);
			ps.setString(2,section);
			ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return 0;
	}
	
}