import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class ReturnBook extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static ReturnBook frame;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new ReturnBook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ReturnBook() {
		setType(Type.UTILITY);
		setResizable(false);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(0, 0, 840, 441);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setLayout(null);
		
		ImageIcon image2= new ImageIcon(getClass().getResource("logosmol.png"));
		
		ImageIcon image3= new ImageIcon(getClass().getResource("outline.png"));
		
		setIconImage(image3.getImage());
		
		JLabel lblNewLabel_2 = new JLabel(image2);
		lblNewLabel_2.setBounds(556, 42, 306, 232);
		contentPane.add(lblNewLabel_2);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 51));
		panel.setBounds(0, 0, 824, 149);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("Mabiga, Mabalacat City Pampanga");
		lblNewLabel_6.setBounds(29, 69, 344, 30);
		panel.add(lblNewLabel_6);
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setFont(new Font("Verdana", Font.PLAIN, 20));
		
		JLabel lblNewLabel_5 = new JLabel("CHILDREN OF FATIMA SCHOOL, INC.");
		lblNewLabel_5.setBounds(29, 31, 557, 42);
		panel.add(lblNewLabel_5);
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBackground(new Color(255, 255, 255));
		lblNewLabel_5.setFont(new Font("Algerian", Font.PLAIN, 35));
		
		JLabel lblNewLabel = new JLabel("Return Book");
		lblNewLabel.setForeground(new Color(0, 0, 51));
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 25));
		lblNewLabel.setBounds(27, 162, 146, 30);
		contentPane.add(lblNewLabel);
		
		JLabel lblBookCallno = new JLabel("Book ID:");
		lblBookCallno.setHorizontalAlignment(SwingConstants.RIGHT);
		lblBookCallno.setBounds(63, 215, 109, 18);
		contentPane.add(lblBookCallno);
		lblBookCallno.setForeground(new Color(0, 0, 102));
		lblBookCallno.setFont(new Font("Century Gothic", Font.BOLD, 20));
		
		JLabel lblStudentId = new JLabel("Student ID:");
		lblStudentId.setBounds(64, 269, 109, 18);
		contentPane.add(lblStudentId);
		lblStudentId.setHorizontalAlignment(SwingConstants.RIGHT);
		lblStudentId .setForeground(new Color(0, 0, 102));
		lblStudentId .setFont(new Font("Century Gothic", Font.BOLD, 20));
		
		textField = new JTextField();
		textField.setBackground(new Color(198, 226, 255));
		textField.setBounds(183, 264, 344, 30);
		textField.setColumns(10);
		contentPane.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setBackground(new Color(198, 226, 255));
		textField_1.setBounds(183, 210, 344, 30);
		textField_1.setColumns(10);
		contentPane.add(textField_1);
		
		JLabel lblStudentName = new JLabel("Status:");
		lblStudentName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblStudentName.setForeground(new Color(0, 0, 102));
		lblStudentName.setFont(new Font("Century Gothic", Font.BOLD, 20));
		lblStudentName.setBounds(319, 326, 89, 18);
		contentPane.add(lblStudentName);
		
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBackground(new Color(198, 226, 255));
		textField_2.setBounds(418, 320, 109, 30);
		contentPane.add(textField_2);
		
		JLabel lblDateIssued = new JLabel("Issued:");
		lblDateIssued.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDateIssued.setForeground(new Color(0, 0, 102));
		lblDateIssued.setFont(new Font("Century Gothic", Font.BOLD, 20));
		lblDateIssued.setBounds(53, 326, 120, 18);
		contentPane.add(lblDateIssued);
		
		textField_3 = new JTextField();
		textField_3.setEditable(false);
		textField_3.setColumns(10);
		textField_3.setBackground(new Color(198, 226, 255));
		textField_3.setBounds(183, 320, 132, 30);
		contentPane.add(textField_3);
		
		//code
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				Connection con=DB.getConnection();
				
				try {
					PreparedStatement ps=con.prepareStatement("select `Status`, `Date Issued` from `issuebooks` where `Book ID`=? and `Student ID`=?");
					ps.setString(1,textField_1.getText());
					ps.setString(2,textField.getText());
					ResultSet rs=ps.executeQuery();
					
					if (rs.next()) {
						String stat=rs.getString("Status").equals("-")? "On Time": rs.getString("Status");
						String issue=rs.getString("Date Issued");
						
						textField_2.setText(stat);
						textField_3.setText(issue);
					}	
				}  catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		JButton btnReturnBook = new JButton("Return Book");
		btnReturnBook.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnReturnBook.setForeground(new Color(255, 255, 255));
		btnReturnBook.setBackground(new Color(0, 0, 102));
		btnReturnBook.setBounds(592, 285, 136, 37);
		contentPane.add(btnReturnBook);
		btnReturnBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String callno=textField_1.getText();
				String studentid=textField.getText();
				String issue=textField_3.getText();
				String stat=textField_2.getText();
				
				int i=ReturnBookDao.delete(callno, studentid);
				int ii=ReturnBookDao.update(callno, studentid, stat,issue);
				if(i>0 && ii>0){
					JOptionPane.showMessageDialog(ReturnBook.this,"Book returned successfully!");
					LibrarianSuccess.main(new String[]{});
					frame.dispose();
					
				}else{
					JOptionPane.showMessageDialog(ReturnBook.this,"Sorry, unable to return book!");
				}
				
			}
		});
		
		JLabel lblNewLabel2 = new JLabel("Note: Check the book properly!");
		lblNewLabel2.setBounds(183, 240, 177, 16);
		contentPane.add(lblNewLabel2);
		lblNewLabel2.setForeground(Color.RED);
		lblNewLabel2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(new Color(0, 0, 102));
		btnBack.setForeground(new Color(255, 255, 255));
		btnBack.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnBack.setBounds(10, 361, 89, 30);
		contentPane.add(btnBack);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		contentPane.setLayout(null);
		
		
		
	}
}