import java.sql.Connection;
import java.sql.PreparedStatement;
public class StudentDao {

	
	public static int save(String LRN,String LastName,Object strand,Object gradeAndSection, String Contact){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into student(`Student ID`, `Student Name`, `Strand`, `Grade & Section`, `Contact Number`) values(?,?,?,?,?)");
			ps.setString(1,LRN);
			ps.setString(2,LastName);
			ps.setObject(3,strand);
			ps.setObject(4,gradeAndSection);
			ps.setString(5,Contact);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}

	public static int delete(String LRN) {
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from `student` where `Student ID`=?");
			ps.setString(1,LRN);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}

	public static int update(String no,String LRN,String LastName,Object strand,Object gradeAndSection, String Contact) {
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("update student set `Student ID`=?, `Student Name`=?, `Strand`=?, `Grade & Section`=?, `Contact Number`=? where `No.`=?");
			ps.setString(1,LRN);
			ps.setString(2,LastName);
			ps.setObject(3,strand);
			ps.setObject(4,gradeAndSection);
			ps.setString(5,Contact);
			ps.setString(6,no);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
		
	}
}
