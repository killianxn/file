import java.sql.*;
public class IssueBookDao {
	
public static int save(String callno1, String booktitle1, String studentid1, String studentname1, String studentcontact1, String due1){
	int status=0;
	try{
		Connection con=DB.getConnection();
		
		status=updatebook(callno1);
		if(status>0){
		PreparedStatement ps1=con.prepareStatement("insert into `issuebooks`(`Book ID`, `Book Title`, `Student ID`, `Student Name`, `Contact Number`, `Date Due`) values(?,?,?,?,?,?)");
		ps1.setString(1,callno1);
		ps1.setString(2,booktitle1);
		ps1.setString(3,studentid1);
		ps1.setString(4,studentname1);
		ps1.setString(5,studentcontact1);
		ps1.setString(6,due1);
		status=ps1.executeUpdate();
		}
		
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static int save(String callno1, String booktitle1, String studentid1, String studentname1, String studentcontact1){
	int status=0;
	try{
		Connection con=DB.getConnection();
		PreparedStatement ps=con.prepareStatement("insert into history(`Book ID`, `Book Title`, `Student ID`, `Student Name`, `Contact Number`) values(?,?,?,?,?)");
		ps.setString(1,callno1);
		ps.setString(2,booktitle1);
		ps.setString(3,studentid1);
		ps.setString(4,studentname1);
		ps.setString(5,studentcontact1);
		status=ps.executeUpdate();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static int updatebook(String callno1){
	int status=0;
	int quantity=0,issued=0;
	try{
		Connection con=DB.getConnection();
		
		PreparedStatement ps=con.prepareStatement("select `Available`,`Transacted` from `books` where `Book ID`=?");
		ps.setString(1,callno1);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			quantity=rs.getInt("Available");
			issued=rs.getInt("Transacted");
		}
		
		if(quantity>0){
		PreparedStatement ps2=con.prepareStatement("update `books` set `Available`=?, `Transacted`=? where `Book ID`=?");
		ps2.setInt(1,quantity-1);
		ps2.setInt(2,issued+1);
		ps2.setString(3,callno1);
		
		status=ps2.executeUpdate();
		}
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
}