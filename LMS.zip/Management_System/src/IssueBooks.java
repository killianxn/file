import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class IssueBooks extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static IssueBooks frame;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new IssueBooks();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IssueBooks() {
		setType(Type.UTILITY);
		setResizable(false);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(0, 0, 840, 441);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setLayout(null);
		
		ImageIcon image2= new ImageIcon(getClass().getResource("logosmol.png"));
		
		ImageIcon image3= new ImageIcon(getClass().getResource("outline.png"));
		
		setIconImage(image3.getImage());
		
		JLabel lblNewLabel_2 = new JLabel(image2);
		lblNewLabel_2.setBounds(556, 42, 306, 232);
		contentPane.add(lblNewLabel_2);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 51));
		panel.setBounds(0, 0, 824, 149);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("Mabiga, Mabalacat City Pampanga");
		lblNewLabel_6.setBounds(29, 69, 344, 30);
		panel.add(lblNewLabel_6);
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setFont(new Font("Verdana", Font.PLAIN, 20));
		
		JLabel lblNewLabel_5 = new JLabel("CHILDREN OF FATIMA SCHOOL, INC.");
		lblNewLabel_5.setBounds(29, 31, 557, 42);
		panel.add(lblNewLabel_5);
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBackground(new Color(255, 255, 255));
		lblNewLabel_5.setFont(new Font("Algerian", Font.PLAIN, 35));
		
		JLabel lblNewLabel = new JLabel("Issue Book");
		lblNewLabel.setForeground(new Color(0, 0, 51));
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 25));
		lblNewLabel.setBounds(27, 162, 146, 30);
		contentPane.add(lblNewLabel);
		
		JLabel lblBookCallno = new JLabel("Book ID:");
		lblBookCallno.setHorizontalAlignment(SwingConstants.RIGHT);
		lblBookCallno.setBounds(45, 208, 109, 18);
		contentPane.add(lblBookCallno);
		lblBookCallno.setForeground(new Color(0, 0, 102));
		lblBookCallno.setFont(new Font("Century Gothic", Font.BOLD, 18));
		
		JLabel lblStudentId = new JLabel("Student ID:");
		lblStudentId.setBounds(45, 294, 109, 26);
		contentPane.add(lblStudentId);
		lblStudentId.setHorizontalAlignment(SwingConstants.RIGHT);
		lblStudentId .setForeground(new Color(0, 0, 102));
		lblStudentId .setFont(new Font("Century Gothic", Font.BOLD, 18));
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBackground(new Color(198, 226, 255));
		textField.setBounds(566, 255, 230, 27);
		textField.setColumns(10);
		contentPane.add(textField);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBackground(new Color(198, 226, 255));
		textField_2.setBounds(164, 294, 242, 27);
		contentPane.add(textField_2);
		textField_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				Connection con=DB.getConnection();
				
				try {
					PreparedStatement ps=con.prepareStatement("select `Student Name`, `Contact Number` from `student` where `Student ID`=?");
					ps.setString(1,textField_2.getText());
					ResultSet rs=ps.executeQuery();
					
					if (rs.next()) {
						String name=rs.getString("Student Name");
						String number=rs.getString("Contact Number");
						
						textField.setText(name);
						textField_3.setText(number);
						
					}	
				}  catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		textField_1 = new JTextField();
		textField_1.setBackground(new Color(198, 226, 255));
		textField_1.setBounds(164, 203, 151, 30);
		textField_1.setColumns(10);
		contentPane.add(textField_1);
		textField_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
					Connection con=DB.getConnection();
				
				try {
					PreparedStatement ps=con.prepareStatement("select `Book Title` from `books` where `Book ID`=?");
					ps.setString(1, textField_1.getText());
					ResultSet rs=ps.executeQuery();
					
					if (rs.next()) {
						String booktitle=rs.getString("Book Title");
						textField_4.setText(booktitle);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		JButton btnIssueBook = new JButton("Issue Book");
		btnIssueBook.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnIssueBook.setForeground(new Color(255, 255, 255));
		btnIssueBook.setBackground(new Color(0, 0, 102));
		btnIssueBook.setBounds(574, 343, 136, 37);
		contentPane.add(btnIssueBook);
		btnIssueBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.DATE, 2);
			
				String callno=textField_1.getText();
				String booktitle=textField_4.getText();
				String studentid=textField_2.getText();
				String studentname=textField.getText();
				String studentcontact=textField_3.getText();
				String due=(dateFormat.format(cal.getTime()));
			
			int issue=IssueBookDao.save(callno, booktitle, studentid, studentname, studentcontact, due);
			int history=IssueBookDao.save(callno, booktitle, studentid, studentname, studentcontact);
			
			if(issue>0 && history>0) {
				JOptionPane.showMessageDialog(IssueBooks.this,"Book Issued Successfully!");
				LibrarianSuccess.main(new String[]{});
				frame.dispose();
			} else {
				JOptionPane.showMessageDialog(IssueBooks.this,"Sorry, unable to issue!");
			}//end of save if-else
		
			
			}
		});
		
		JLabel lblNewLabel2 = new JLabel("Note: Check the book properly!");
		lblNewLabel2.setBounds(174, 333, 177, 16);
		contentPane.add(lblNewLabel2);
		lblNewLabel2.setForeground(Color.RED);
		lblNewLabel2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(new Color(0, 0, 102));
		btnBack.setForeground(new Color(255, 255, 255));
		btnBack.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnBack.setBounds(10, 361, 89, 30);
		contentPane.add(btnBack);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		contentPane.setLayout(null);
		
		JLabel lblStudentName = new JLabel("Student Name:");
		lblStudentName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblStudentName.setForeground(new Color(0, 0, 102));
		lblStudentName.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblStudentName.setBounds(410, 256, 146, 26);
		contentPane.add(lblStudentName);
	
		JLabel lblContactNo = new JLabel("Contact No.:");
		lblContactNo.setHorizontalAlignment(SwingConstants.RIGHT);
		lblContactNo.setForeground(new Color(0, 0, 102));
		lblContactNo.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblContactNo.setBounds(430, 292, 126, 28);
		contentPane.add(lblContactNo);
		
		textField_3 = new JTextField();
		textField_3.setEditable(false);
		textField_3.setColumns(10);
		textField_3.setBackground(new Color(198, 226, 255));
		textField_3.setBounds(566, 293, 230, 27);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setEditable(false);
		textField_4.setBackground(new Color(198, 226, 255));
		textField_4.setBounds(164, 255, 242, 27);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblBookTitle = new JLabel("Book Title:");
		lblBookTitle.setHorizontalAlignment(SwingConstants.RIGHT);
		lblBookTitle.setForeground(new Color(0, 0, 102));
		lblBookTitle.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblBookTitle.setBounds(8, 255, 146, 26);
		contentPane.add(lblBookTitle);
		
	}
	
}
 