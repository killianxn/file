import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class LibrarianForm extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static LibrarianForm frame;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_4;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new LibrarianForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LibrarianForm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setBounds(0, 0, 840, 441);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setLayout(null);
		
		ImageIcon image2= new ImageIcon(getClass().getResource("logosmol.png"));
		
		ImageIcon image3= new ImageIcon(getClass().getResource("outline.png"));
		
		setIconImage(image3.getImage());
		
		JLabel lblNewLabel_2 = new JLabel(image2);
		lblNewLabel_2.setBounds(556, 42, 306, 232);
		contentPane.add(lblNewLabel_2);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 51));
		panel.setBounds(0, 0, 824, 149);
		contentPane.add(panel);
		panel.setLayout(null);
		
		contentPane.add(panel);
		
		JLabel lblNewLabel_6 = new JLabel("Mabiga, Mabalacat City Pampanga");
		lblNewLabel_6.setBounds(29, 69, 344, 30);
		panel.add(lblNewLabel_6);
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setFont(new Font("Verdana", Font.PLAIN, 20));
		
		JLabel lblNewLabel_5 = new JLabel("CHILDREN OF FATIMA SCHOOL, INC.");
		lblNewLabel_5.setBounds(29, 31, 557, 42);
		panel.add(lblNewLabel_5);
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBackground(new Color(255, 255, 255));
		lblNewLabel_5.setFont(new Font("Algerian", Font.PLAIN, 35));
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPassword.setBounds(122, 280, 104, 18);
		contentPane.add(lblPassword);
		lblPassword.setForeground(new Color(0, 0, 102));
		lblPassword.setFont(new Font("Century Gothic", Font.BOLD, 15));
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setHorizontalAlignment(SwingConstants.RIGHT);
		lblEmail.setBounds(122, 325, 104, 18);
		contentPane.add(lblEmail);
		lblEmail.setForeground(new Color(0, 0, 102));
		lblEmail.setFont(new Font("Century Gothic", Font.BOLD, 15));
		
		JLabel lblName = new JLabel("Name:");
		lblName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblName.setBounds(117, 205, 109, 18);
		contentPane.add(lblName);
		lblName.setForeground(new Color(0, 0, 102));
		lblName.setFont(new Font("Century Gothic", Font.BOLD, 15));
		
		JLabel lblContactNo = new JLabel("Contact No:");
		lblContactNo.setHorizontalAlignment(SwingConstants.RIGHT);
		lblContactNo.setBounds(117, 367, 109, 18);
		contentPane.add(lblContactNo);
		lblContactNo.setForeground(new Color(0, 0, 102));
		lblContactNo.setFont(new Font("Century Gothic", Font.BOLD, 15));
		
		textField = new JTextField();
		textField.setBounds(236, 206, 259, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(236, 326, 259, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(236, 368, 259, 20);
		contentPane.add(textField_4);
		
		JLabel lblNewLabel = new JLabel("Librarian Form");
		lblNewLabel.setForeground(new Color(0, 0, 51));
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 25));
		lblNewLabel.setBounds(27, 162, 185, 30);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Add Librarian");
		btnNewButton.setBounds(557, 291, 136, 37);
		contentPane.add(btnNewButton);
		btnNewButton.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(0, 0, 102));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String name=textField.getText();
			String user=textField_2.getText();
			String password=textField_3.getText();
			String email=textField_1.getText();
			String contact=textField_4.getText();

			int i=LibrarianDao.save(name, user, password, email, contact);
			if(i>0){
				JOptionPane.showMessageDialog(LibrarianForm.this,"Librarian added successfully!");
				AdminSuccess.main(new String[]{});
				frame.dispose();
				
			}else{
				JOptionPane.showMessageDialog(LibrarianForm.this,"Sorry, unable to save!");
			}
			}
		
		});
		JButton btnback = new JButton("Back");
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminSuccess.main(new String[]{});
				frame.dispose();
			}
		});
		btnback.setBackground(new Color(0, 0, 102));
		btnback.setForeground(new Color(255, 255, 255));
		btnback.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnback.setBounds(10, 361, 89, 30);
		contentPane.add(btnback);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setHorizontalAlignment(SwingConstants.RIGHT);
		lblUsername.setForeground(new Color(0, 0, 102));
		lblUsername.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lblUsername.setBounds(122, 240, 104, 18);
		contentPane.add(lblUsername);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(236, 241, 259, 20);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(236, 281, 259, 20);
		contentPane.add(textField_3);
		
		
		
	}
}
