import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
public class AdminSuccess extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static AdminSuccess frame;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new AdminSuccess();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminSuccess() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("logo.png"));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 840, 441);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setLayout(null);
		
		ImageIcon image2= new ImageIcon(getClass().getResource("logosmol.png"));
		
		ImageIcon image3= new ImageIcon(getClass().getResource("outline.png"));
		
		setIconImage(image3.getImage());
		
		JLabel lblNewLabel_2 = new JLabel(image2);
		lblNewLabel_2.setBounds(556, 42, 306, 232);
		contentPane.add(lblNewLabel_2);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 51));
		panel.setBounds(0, 0, 824, 149);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("Mabiga, Mabalacat City Pampanga");
		lblNewLabel_6.setBounds(29, 69, 344, 30);
		panel.add(lblNewLabel_6);
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setFont(new Font("Verdana", Font.PLAIN, 20));
		
		JLabel lblNewLabel_5 = new JLabel("CHILDREN OF FATIMA SCHOOL, INC.");
		lblNewLabel_5.setBounds(29, 31, 557, 42);
		panel.add(lblNewLabel_5);
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBackground(new Color(255, 255, 255));
		lblNewLabel_5.setFont(new Font("Algerian", Font.PLAIN, 35));
		
		JButton btnNewButton = new JButton("Add Librarian");
		btnNewButton.setBounds(79, 225, 196, 58);
		contentPane.add(btnNewButton);
		btnNewButton.setFont(new Font("Century Gothic", Font.BOLD, 20));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(0, 0, 102));
		
		JLabel lblAdminSection = new JLabel("Admin Section");
		lblAdminSection.setForeground(new Color(0, 0, 51));
		lblAdminSection.setFont(new Font("Century Gothic", Font.BOLD, 25));
		lblAdminSection.setBounds(27, 162, 185, 30);
		contentPane.add(lblAdminSection);
		
		JButton btnViewLibrarian = new JButton("View Librarian");
		btnViewLibrarian.setBounds(79, 307, 196, 58);
		btnViewLibrarian.setForeground(new Color(255, 255, 255));
		btnViewLibrarian.setBackground(new Color(0, 0, 102));
		contentPane.add(btnViewLibrarian);
		btnViewLibrarian.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			ViewLibrarian.main(new String[]{});
			}
		});
		btnViewLibrarian.setFont(new Font("Century Gothic", Font.BOLD, 20));
		
		JButton btnDeleteLibrarian = new JButton("Delete Librarian");
		btnDeleteLibrarian.setBounds(326, 225, 196, 58);
		btnDeleteLibrarian.setForeground(new Color(255, 255, 255));
		btnDeleteLibrarian.setBackground(new Color(0, 0, 102));
		contentPane.add(btnDeleteLibrarian);
		btnDeleteLibrarian.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			DeleteLibrarian.main(new String[]{});
			frame.dispose();
			}
		});
		btnDeleteLibrarian.setFont(new Font("Century Gothic", Font.BOLD, 20));
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.setBounds(326, 307, 196, 58);
		btnLogout.setForeground(new Color(255, 255, 255));
		btnLogout.setBackground(new Color(0, 0, 102));
		contentPane.add(btnLogout);
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Library.main(new String[]{});
				frame.dispose();
			}
		});
		btnLogout.setFont(new Font("Century Gothic", Font.BOLD, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			LibrarianForm.main(new String[]{});
			frame.dispose();
			}
		});
		
	
	}
}
