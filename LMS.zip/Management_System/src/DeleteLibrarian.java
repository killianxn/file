import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class DeleteLibrarian extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static DeleteLibrarian frame;
	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new DeleteLibrarian();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteLibrarian() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setBounds(0, 0, 840, 441);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setLayout(null);
		
		ImageIcon image2= new ImageIcon(getClass().getResource("logosmol.png"));
		
		ImageIcon image3= new ImageIcon(getClass().getResource("outline.png"));
		
		setIconImage(image3.getImage());
		
		JLabel lblNewLabel_2 = new JLabel(image2);
		lblNewLabel_2.setBounds(556, 42, 306, 232);
		contentPane.add(lblNewLabel_2);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 51));
		panel.setBounds(0, 0, 824, 149);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("Mabiga, Mabalacat City Pampanga");
		lblNewLabel_6.setBounds(29, 69, 344, 30);
		panel.add(lblNewLabel_6);
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setFont(new Font("Verdana", Font.PLAIN, 20));
		
		JLabel lblNewLabel_5 = new JLabel("CHILDREN OF FATIMA SCHOOL, INC.");
		lblNewLabel_5.setBounds(29, 31, 557, 42);
		panel.add(lblNewLabel_5);
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBackground(new Color(255, 255, 255));
		lblNewLabel_5.setFont(new Font("Algerian", Font.PLAIN, 35));
		
		JLabel lblNewLabel = new JLabel("Delete Librarian");
		lblNewLabel.setForeground(new Color(0, 0, 51));
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 25));
		lblNewLabel.setBounds(27, 162, 253, 30);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBackground(new Color(198, 226, 255));
		textField.setBounds(186, 234, 344, 30);
		textField.setColumns(10);
		contentPane.setLayout(null);
		contentPane.add(textField);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnDelete.setForeground(new Color(255, 255, 255));
		btnDelete.setBackground(new Color(0, 0, 102));
		btnDelete.setBounds(273, 294, 136, 37);
		contentPane.add(btnDelete);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sid=textField.getText();
				if(sid==null||sid.trim().equals("")){
					JOptionPane.showMessageDialog(DeleteLibrarian.this,"Id can't be blank");
				}else{
					int id=Integer.parseInt(sid);
					int i=LibrarianDao.delete(id);
					if(i>0){
						JOptionPane.showMessageDialog(DeleteLibrarian.this,"Record deleted successfully!");
					}else{
						JOptionPane.showMessageDialog(DeleteLibrarian.this,"Unable to delete given id!");
					}
				}
			}
		});
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminSuccess.main(new String[]{});
				frame.dispose();
			}
		});
		btnNewButton.setBackground(new Color(0, 0, 102));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnNewButton.setBounds(10, 361, 89, 30);
		contentPane.add(btnNewButton);
		
		
		JLabel lblEnterId = new JLabel("Enter Id:");
		lblEnterId.setBounds(67, 240, 109, 18);
		contentPane.add(lblEnterId);
		lblEnterId.setHorizontalAlignment(SwingConstants.RIGHT);
		lblEnterId .setForeground(new Color(0, 0, 102));
		lblEnterId .setFont(new Font("Century Gothic", Font.BOLD, 20));
		
	}
}
