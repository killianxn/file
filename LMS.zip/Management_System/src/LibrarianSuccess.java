import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import net.proteanit.sql.DbUtils;

public class LibrarianSuccess extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static LibrarianSuccess frame1;
	private JPanel contentPane;
	private JTextField textFieldsection;
	private JTable table;
	private JTable table1;
	private JTable table3;
	private JTable table4;
	private JTextField textFieldname;
	private JTable table_1;
	private JLabel btnNewLbl_2_2;
	@SuppressWarnings("rawtypes")
	private JComboBox comboBox;
	@SuppressWarnings("rawtypes")
	private JComboBox comboBox_1;
	private DefaultComboBoxModel<String> defaultSecondComboBoxModel;


	
	public void refreshTable() {
		try {
			Connection conn=DB.getConnection();
			String sql = "select * from logs";
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			table.getColumnModel().getColumn(0).setPreferredWidth(100);
			table.getColumnModel().getColumn(0).setMaxWidth(100);
			table.getColumnModel().getColumn(1).setPreferredWidth(535);
			table.getColumnModel().getColumn(1).setMaxWidth(535);
			table.getColumnModel().getColumn(2).setPreferredWidth(250);
			table.getColumnModel().getColumn(2).setMaxWidth(250);
			table.getColumnModel().getColumn(3).setPreferredWidth(250);
			table.getColumnModel().getColumn(3).setMaxWidth(250);
			table.getColumnModel().getColumn(4).setPreferredWidth(250);
			table.getColumnModel().getColumn(4).setMaxWidth(250);
		    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void refreshTablebooks() {
		try {
			Connection conn=DB.getConnection();
			String sql = "select * from books";
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			table1.setModel(DbUtils.resultSetToTableModel(rs));
			table1.getColumnModel().getColumn(0).setPreferredWidth(100);
			table1.getColumnModel().getColumn(0).setMaxWidth(100);
			table1.getColumnModel().getColumn(1).setPreferredWidth(450);
			table1.getColumnModel().getColumn(1).setMaxWidth(450);
			table1.getColumnModel().getColumn(2).setPreferredWidth(200);
			table1.getColumnModel().getColumn(2).setMaxWidth(200);
			table1.getColumnModel().getColumn(3).setPreferredWidth(200);
			table1.getColumnModel().getColumn(3).setMaxWidth(200);
			table1.getColumnModel().getColumn(4).setPreferredWidth(100);
			table1.getColumnModel().getColumn(4).setMaxWidth(100);
			table1.getColumnModel().getColumn(5).setPreferredWidth(100);
			table1.getColumnModel().getColumn(5).setMaxWidth(100);
			table1.getColumnModel().getColumn(6).setPreferredWidth(233);
			table1.getColumnModel().getColumn(6).setMaxWidth(233);
			table1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void refreshTablestudent() {
		try {
			Connection conn=DB.getConnection();
			String sql = "select * from student";
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			table3.setModel(DbUtils.resultSetToTableModel(rs));
			table3.getColumnModel().getColumn(0).setPreferredWidth(70);
			table3.getColumnModel().getColumn(0).setMaxWidth(70);
			table3.getColumnModel().getColumn(1).setPreferredWidth(200);
			table3.getColumnModel().getColumn(1).setMaxWidth(200);
			table3.getColumnModel().getColumn(2).setPreferredWidth(500);
			table3.getColumnModel().getColumn(2).setMaxWidth(500);
			table3.getColumnModel().getColumn(3).setPreferredWidth(130);
			table3.getColumnModel().getColumn(3).setMaxWidth(130);
			table3.getColumnModel().getColumn(4).setPreferredWidth(200);
			table3.getColumnModel().getColumn(4).setMaxWidth(200);
			table3.getColumnModel().getColumn(5).setPreferredWidth(282);
			table3.getColumnModel().getColumn(5).setMaxWidth(282);
			table3.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void markOverdueRows(JTable table, int dateColumnIndex) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate currentDate = LocalDate.now();

        for (int row = 0; row < model.getRowCount(); row++) {
            String dateString = (String) model.getValueAt(row, dateColumnIndex);
            LocalDate date = LocalDate.parse(dateString, formatter);

            if (date.isBefore(currentDate)) {
                model.setValueAt("Overdue", row, 0); 
            }
        }
    }
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame1 = new LibrarianSuccess();
					frame1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public LibrarianSuccess() {
		setUndecorated(true);
		setResizable(false);
		setExtendedState(Frame.MAXIMIZED_BOTH);
		setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 12));
		setForeground(new Color(0, 0, 51));
		setTitle("AutoLib - DashBoard");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1920, 1050);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 4, 23));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ImageIcon image= new ImageIcon(getClass().getResource("sorkol.png"));
		
		ImageIcon image1= new ImageIcon(getClass().getResource("borders3.png"));
		
		ImageIcon image3= new ImageIcon(getClass().getResource("borders2.png"));
		
		ImageIcon image4= new ImageIcon(getClass().getResource("preview.png"));
		
		ImageIcon image5= new ImageIcon(getClass().getResource("books.png"));
		
		ImageIcon image6= new ImageIcon(getClass().getResource("history.png"));
		
		ImageIcon image7= new ImageIcon(getClass().getResource("issue.png"));
		
		ImageIcon image8= new ImageIcon(getClass().getResource("logs.png"));
		
		ImageIcon image9= new ImageIcon(getClass().getResource("return.png"));
		
		ImageIcon image0= new ImageIcon(getClass().getResource("student.png"));
		
		ImageIcon image10= new ImageIcon(getClass().getResource("logout.png"));
		
		ImageIcon image11= new ImageIcon(getClass().getResource("outline.png"));
		
		ImageIcon image12= new ImageIcon(getClass().getResource("outline.png"));
		
		setIconImage(image12.getImage());
		
		
		//dashboard
		JDesktopPane desktopPane5 = new JDesktopPane();
		desktopPane5.setBackground(new Color(255, 255, 255));
		desktopPane5.setBounds(456, 9, 1458, 1050);
		contentPane.add(desktopPane5);
		desktopPane5.setVisible(true);
		
		JButton btnNewButton_2_4 = new JButton("Log Sheet");
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(new Color(0, 0, 51));
		panel_1.setBounds(1045, 0, 420, 1050);
		desktopPane5.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Amount Summary");
		lblNewLabel_4.setFont(new Font("Century Gothic", Font.BOLD, 35));
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setBounds(10, 23, 400, 40);
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_9_1_1_1 = new JLabel("Students");
		lblNewLabel_9_1_1_1.setForeground(new Color(0, 0, 51));
		lblNewLabel_9_1_1_1.setFont(new Font("Century Gothic", Font.PLAIN, 22));
		lblNewLabel_9_1_1_1.setBounds(30, 793, 250, 25);
		panel_1.add(lblNewLabel_9_1_1_1);
		
		JLabel lblNewLabel_9_1_1 = new JLabel("Over Due Books");
		lblNewLabel_9_1_1.setForeground(new Color(0, 0, 51));
		lblNewLabel_9_1_1.setFont(new Font("Century Gothic", Font.PLAIN, 22));
		lblNewLabel_9_1_1.setBounds(30, 568, 250, 25);
		panel_1.add(lblNewLabel_9_1_1);
		
		JLabel lblNewLabel_9_1 = new JLabel("Issued Books");
		lblNewLabel_9_1.setForeground(new Color(0, 0, 51));
		lblNewLabel_9_1.setFont(new Font("Century Gothic", Font.PLAIN, 22));
		lblNewLabel_9_1.setBounds(30, 343, 150, 25);
		panel_1.add(lblNewLabel_9_1);
		
		JLabel lblNewLabel_9 = new JLabel("Books");
		lblNewLabel_9.setForeground(new Color(0, 0, 51));
		lblNewLabel_9.setFont(new Font("Century Gothic", Font.PLAIN, 22));
		lblNewLabel_9.setBounds(30, 119, 70, 25);
		panel_1.add(lblNewLabel_9);
		
		JLabel btnNewLbl_2 = new JLabel();
		btnNewLbl_2.setHorizontalAlignment(SwingConstants.CENTER);
		btnNewLbl_2.setOpaque(true);
		btnNewLbl_2.setHorizontalTextPosition(SwingConstants.CENTER);
		btnNewLbl_2.setBackground(new Color(255, 255, 255));
		btnNewLbl_2.setForeground(new Color(0, 0, 51));
		btnNewLbl_2.setBorder(new LineBorder(new Color(193,156,81), 10));
		btnNewLbl_2.setFont(new Font("Century Gothic", Font.BOLD, 40));
		btnNewLbl_2.setBounds(10, 99, 393, 190);
		panel_1.add(btnNewLbl_2);
		
		btnNewLbl_2.setText(String.valueOf(func.countData("books")));
		
		JLabel btnNewLbl_2_1 = new JLabel();
		btnNewLbl_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		btnNewLbl_2_1.setOpaque(true);
		btnNewLbl_2_1.setHorizontalTextPosition(SwingConstants.CENTER);
		btnNewLbl_2_1.setForeground(new Color(0, 0, 51));
		btnNewLbl_2_1.setFont(new Font("Century Gothic", Font.BOLD, 40));
		btnNewLbl_2_1.setBorder(new LineBorder(new Color(193,156,81), 10));
		btnNewLbl_2_1.setBackground(Color.WHITE);
		btnNewLbl_2_1.setBounds(10, 324, 393, 190);
		panel_1.add(btnNewLbl_2_1);
		
		btnNewLbl_2_1.setText(String.valueOf(func.countData("issuebooks")));
		
		btnNewLbl_2_2 = new JLabel();
		btnNewLbl_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		btnNewLbl_2_2.setOpaque(true);
		btnNewLbl_2_2.setHorizontalTextPosition(SwingConstants.CENTER);
		btnNewLbl_2_2.setForeground(new Color(0, 0, 51));
		btnNewLbl_2_2.setFont(new Font("Century Gothic", Font.BOLD, 40));
		btnNewLbl_2_2.setBorder(new LineBorder(new Color(193,156,81), 10));
		btnNewLbl_2_2.setBackground(Color.WHITE);
		btnNewLbl_2_2.setBounds(10, 549, 393, 190);
		panel_1.add(btnNewLbl_2_2);

		JLabel btnNewLbl_2_3 = new JLabel();
		btnNewLbl_2_3.setHorizontalAlignment(SwingConstants.CENTER);
		btnNewLbl_2_3.setOpaque(true);
		btnNewLbl_2_3.setHorizontalTextPosition(SwingConstants.CENTER);
		btnNewLbl_2_3.setForeground(new Color(0, 0, 51));
		btnNewLbl_2_3.setFont(new Font("Century Gothic", Font.BOLD, 40));
		btnNewLbl_2_3.setBorder(new LineBorder(new Color(193,156,81), 10));
		btnNewLbl_2_3.setBackground(Color.WHITE);
		btnNewLbl_2_3.setBounds(10, 774, 393, 190);
		panel_1.add(btnNewLbl_2_3);
		
		btnNewLbl_2_3.setText(String.valueOf(func.countData("student")));
		
		btnNewButton_2_4.setHorizontalTextPosition(SwingConstants.CENTER);
		btnNewButton_2_4.setIcon(image4);
		btnNewButton_2_4.setForeground(new Color(0, 0, 51));
		btnNewButton_2_4.setFont(new Font("Century Gothic", Font.BOLD, 40));
		btnNewButton_2_4.setBorder(new LineBorder(new Color(0, 0, 51), 10));
		btnNewButton_2_4.setBackground(Color.WHITE);
		btnNewButton_2_4.setBounds(49, 83, 953, 254);
		desktopPane5.add(btnNewButton_2_4);
		
		//table for issued books
		String data5[][]=null;
		String column5[]=null;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from issuebooks",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			
			ResultSetMetaData rsmd=rs.getMetaData();
			int cols=rsmd.getColumnCount();
			column5=new String[cols];
			for(int i=1;i<=cols;i++){
				column5[i-1]=rsmd.getColumnName(i);
			}
			
			rs.last();
			int rows=rs.getRow();
			rs.beforeFirst();

			data5=new String[rows][cols];
			int count5=0;
			while(rs.next()){
				for(int i=1;i<=cols;i++){
					data5[count5][i-1]=rs.getString(i);
				}
				count5++;
			}
			con.close();
		}catch(Exception e){System.out.println(e);
		}
		
		DefaultTableModel model5 = new DefaultTableModel(data5, column5);
		table_1 = new JTable(model5) {
			 private static final long serialVersionUID = 1L;

	            @Override
	            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
	                Component c = super.prepareRenderer(renderer, row, column);

	                if (!isRowSelected(row)) {
	                    if (table_1.getColumnCount() >= 0) {
	                        String type = (String)getModel().getValueAt(row, 0);
	                        if (type.equalsIgnoreCase("Overdue")) {
	                            c.setBackground(new Color(153,0,0));
	                            c.setForeground(new Color(255, 255, 255));
	                        } else {
	                        	 c.setBackground(table_1.getBackground());
	                             c.setForeground(table_1.getForeground());
	                        }
	                    }
	                }
	                return c;
	            } 
	        };
	    markOverdueRows(table_1, 7);
	    
	    //counting of overdue in jtable
	    int rowCount = 0;
        for (int i = 0; i < model5.getRowCount(); i++) {
            if (model5.getValueAt(i, 0).equals("Overdue")) {
                rowCount++;
            }
        }
        
        btnNewLbl_2_2.setText(String.valueOf(rowCount));
        
		table_1.setBackground(new Color(0, 0, 0, 0));
		table_1.setShowVerticalLines(false);
		table_1.setForeground(new Color(0, 0, 51));
		table_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table_1.setGridColor(new Color(0, 0, 0));
		table_1.setBorder(null);
		table_1.setOpaque(false);
		table_1.getColumnModel().getColumn(0).setPreferredWidth(100);
		table_1.getColumnModel().getColumn(0).setMaxWidth(100);
		table_1.getColumnModel().getColumn(1).setPreferredWidth(150);
		table_1.getColumnModel().getColumn(1).setMaxWidth(150);
		table_1.getColumnModel().getColumn(2).setPreferredWidth(500);
		table_1.getColumnModel().getColumn(2).setMaxWidth(500);
		table_1.getColumnModel().getColumn(3).setPreferredWidth(150);
		table_1.getColumnModel().getColumn(3).setMaxWidth(150);
		table_1.getColumnModel().getColumn(4).setPreferredWidth(300);
		table_1.getColumnModel().getColumn(4).setMaxWidth(300);
		table_1.getColumnModel().getColumn(5).setPreferredWidth(170);
		table_1.getColumnModel().getColumn(5).setMaxWidth(170);
		table_1.getColumnModel().getColumn(6).setPreferredWidth(150);
		table_1.getColumnModel().getColumn(6).setMaxWidth(150);
		table_1.getColumnModel().getColumn(7).setPreferredWidth(150);
		table_1.getColumnModel().getColumn(7).setMaxWidth(150);
		table_1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table_1.setRowHeight(25);
		table_1.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		
		JScrollPane scrollPane = new JScrollPane(table_1);
		scrollPane.setSize(1022, 640);
		scrollPane.setLocation(10, 399);
		scrollPane.setOpaque(false);
		desktopPane5.add(scrollPane);
		scrollPane.setViewportBorder(null);
		scrollPane.setBorder(null);
		scrollPane.setOpaque(false);
		scrollPane.getViewport();
		
		JLabel lblNewLabel_4_1 = new JLabel("Dashboard");
		lblNewLabel_4_1.setVerticalTextPosition(SwingConstants.BOTTOM);
		lblNewLabel_4_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_4_1.setFont(new Font("Century Gothic", Font.BOLD, 55));
		lblNewLabel_4_1.setBounds(10, 11, 302, 61);
		desktopPane5.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_8 = new JLabel("Transacted Book List");
		lblNewLabel_8.setForeground(new Color(0, 0, 51));
		lblNewLabel_8.setFont(new Font("Century Gothic", Font.BOLD, 35));
		lblNewLabel_8.setBounds(10, 348, 353, 52);
		desktopPane5.add(lblNewLabel_8);
		
	
		JLabel lblNewLabel_81 = new JLabel(image3);
		lblNewLabel_81.setForeground(new Color(0, 0, 51));
		lblNewLabel_81.setFont(new Font("Century Gothic", Font.BOLD, 35));
		lblNewLabel_81.setBounds(-228, -38, 1284, 1352);
		desktopPane5.add(lblNewLabel_81);
		
		
		//log sheet
		JDesktopPane desktopPane2 = new JDesktopPane();
		desktopPane2.setBackground(new Color(255, 255, 255));
		desktopPane2.setBounds(456, 9, 1458, 1050);
		contentPane.add(desktopPane2);
		desktopPane2.setVisible(false);
		
		JButton btnUpdateTimeOut = new JButton("Update Time Out");
		btnUpdateTimeOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name=textFieldname.getText();
				String section=textFieldsection.getText();
				int i= LogSheetDao.update(name, section);
				if(i==0){
					JOptionPane.showMessageDialog(LibrarianSuccess.this,"Time Out success!");
					textFieldname.setText("");
					textFieldsection.setText("");
				}
				refreshTable();
			}
		});
				
		btnUpdateTimeOut.setForeground(Color.WHITE);
		btnUpdateTimeOut.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnUpdateTimeOut.setBackground(new Color(0, 0, 51));
		btnUpdateTimeOut.setBounds(534, 147, 183, 30);
		desktopPane2.add(btnUpdateTimeOut);
		
		JLabel lblNewLabel_1 = new JLabel("Log Sheet");
		lblNewLabel_1.setForeground(new Color(0, 0, 51));
		lblNewLabel_1.setFont(new Font("Franklin Gothic Heavy", Font.BOLD, 40));
		lblNewLabel_1.setBounds(10, 11, 210, 58);
		desktopPane2.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Name:");
		lblNewLabel_2.setForeground(new Color(0, 0, 51));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblNewLabel_2.setBounds(88, 93, 93, 26);
		desktopPane2.add(lblNewLabel_2);
		
		textFieldname = new JTextField();
		textFieldname.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		textFieldname.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textFieldname.setBounds(191, 93, 290, 26);
		desktopPane2.add(textFieldname);
		textFieldname.setColumns(10);
		
		textFieldsection = new JTextField();
		textFieldsection.setBackground(new Color(255, 255, 255));
		textFieldsection.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		textFieldsection.setMargin(new Insets(0, 0, 0, 0));
		textFieldsection.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textFieldsection.setBounds(191, 151, 290, 26);
		desktopPane2.add(textFieldsection);
		textFieldsection.setColumns(10);
		
		JButton btnNewButton1 = new JButton("Add Log");
		btnNewButton1.setBounds(534, 93, 183, 30);
		desktopPane2.add(btnNewButton1);
		btnNewButton1.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnNewButton1.setForeground(new Color(255, 255, 255));
		btnNewButton1.setBackground(new Color(0, 0, 51));
		btnNewButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name=textFieldname.getText();
				String section=textFieldsection.getText();
				if (name==null||name.trim().equals("")) {
					JOptionPane.showMessageDialog(LibrarianSuccess.this,"Name can't be blank");
				} else if (section==null||section.trim().equals("")) {
					JOptionPane.showMessageDialog(LibrarianSuccess.this,"Grade & Section can't be blank");
				} else {
				int i=LogSheetDao.save(name, section);
				if(i>0){
					JOptionPane.showMessageDialog(LibrarianSuccess.this,"Login success!");
					textFieldname.setText("");
					textFieldsection.setText("");
				}else{
					JOptionPane.showMessageDialog(LibrarianSuccess.this,"Sorry, unable to log!");
				}
				refreshTable();
			}
				
				// Select the newly added row in the JTable
	            int rowIndex = table.getRowCount() - 1;
	            table.setRowSelectionInterval(rowIndex, rowIndex);

	            // Scroll to the newly added row
	            table.scrollRectToVisible(table.getCellRect(rowIndex, 0, true));
				
			}
		});
		
		//log sheet table
		String data[][]=null;
		String column[]=null;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from logs",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			
			ResultSetMetaData rsmd=rs.getMetaData();
			int cols=rsmd.getColumnCount();
			column=new String[cols];
			for(int i=1;i<=cols;i++){
				column[i-1]=rsmd.getColumnName(i);
			}
			
			rs.last();
			int rows=rs.getRow();
			rs.beforeFirst();

			data=new String[rows][cols];
			int count=0;
			while(rs.next()){
				for(int i=1;i<=cols;i++){
					data[count][i-1]=rs.getString(i);
				}
				count++;
			}
			con.close();
		}catch(Exception e){System.out.println(e);
		}
		
		table = new JTable(data,column);
		table.setShowVerticalLines(false);
		table.setForeground(new Color(0, 0, 51));
		table.setGridColor(new Color(0, 0, 0));
		table.setBorder(null);
		table.setOpaque(false);
		table.setBackground(new Color(0, 0, 0, 0));
		table.getColumnModel().getColumn(0).setPreferredWidth(100);
		table.getColumnModel().getColumn(0).setMaxWidth(100);
		table.getColumnModel().getColumn(1).setPreferredWidth(535);
		table.getColumnModel().getColumn(1).setMaxWidth(535);
		table.getColumnModel().getColumn(2).setPreferredWidth(250);
		table.getColumnModel().getColumn(2).setMaxWidth(250);
		table.getColumnModel().getColumn(3).setPreferredWidth(250);
		table.getColumnModel().getColumn(3).setMaxWidth(250);
		table.getColumnModel().getColumn(4).setPreferredWidth(250);
		table.getColumnModel().getColumn(4).setMaxWidth(250);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int column = 1;
				int row = table.getSelectedRow();
				String name = table.getModel().getValueAt(row, column).toString();
				
				int column1 = 2;
				int row1 = table.getSelectedRow();
				String section = table.getModel().getValueAt(row1, column1).toString();
				
				textFieldname.setText(name);
				textFieldsection.setText(section);
				
				refreshTable();
			}
		});
				
		table.setRowHeight(25);
		table.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		JScrollPane sp=new JScrollPane(table);
		sp.setViewportBorder(null);
		sp.setBorder(null);
		sp.setOpaque(false);
		sp.getViewport().setOpaque(false);
		sp.setSize(1386, 750);
		sp.setLocation(32, 276);
		desktopPane2.add(sp);
		
		JLabel lblNewLabel_2_1 = new JLabel("Grade & Section:");
		lblNewLabel_2_1.setForeground(new Color(0, 0, 51));
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_1.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblNewLabel_2_1.setBounds(24, 149, 160, 26);
		desktopPane2.add(lblNewLabel_2_1);
		
		
		JLabel lblBookName4 = new JLabel("Book Callno:");
		lblBookName4.setBounds(140, 80, 151, 18);
		desktopPane2.add(lblBookName4);
		lblBookName4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblBookName4.setForeground(new Color(255, 255, 255));
		lblBookName4.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JLabel lblNewLabel_5 = new JLabel("*Click on the row to update Time Out");
		lblNewLabel_5.setForeground(new Color(0, 0, 128));
		lblNewLabel_5.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel_5.setBounds(191, 200, 370, 20);
		desktopPane2.add(lblNewLabel_5);
		
		JLabel lblNewLabel_23 = new JLabel(image);
		lblNewLabel_23.setBounds(1070, -102, 500, 493);
		desktopPane2.add(lblNewLabel_23);
		
		
		JLabel lblNewLabel_7 = new JLabel(image1);
		lblNewLabel_7.setBounds(231, 0, 1361, 1114);
		desktopPane2.add(lblNewLabel_7);
		

		//add and delete books
		JDesktopPane desktopPane1 = new JDesktopPane();
		desktopPane1.setBackground(new Color(255, 255, 255));
		desktopPane1.setBounds(456, 9, 1458, 1050);
		contentPane.add(desktopPane1);
		desktopPane1.setVisible(false);
		
		JLabel lblNewLabel = new JLabel("Search:");
		lblNewLabel.setForeground(new Color(0,0,51));
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 20));
		lblNewLabel.setBounds(839, 227, 74, 27);
		desktopPane1.add(lblNewLabel);
		
		//book search field
		JTextField textField_81 = new JTextField();
		textField_81.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textField_81.setFont(new Font("Century Gothic", Font.PLAIN, 16));
		textField_81.setBounds(923, 228, 233, 27);
		desktopPane1.add(textField_81);
		textField_81.setColumns(10);
		textField_81.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				TableModel model=(TableModel)table1.getModel();
				String search= textField_81.getText();
				TableRowSorter<TableModel>tr= new TableRowSorter<TableModel>(model);
				table1.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
			}
		});
		
		String data1[][]=null;
		String column1[]=null;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from books",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			
			ResultSetMetaData rsmd=rs.getMetaData();
			int cols=rsmd.getColumnCount();
			column1=new String[cols];
			for(int i=1;i<=cols;i++){
				column1[i-1]=rsmd.getColumnName(i);
			}
			
			rs.last();
			int rows=rs.getRow();
			rs.beforeFirst();

			data1=new String[rows][cols];
			int count=0;
			while(rs.next()){
				for(int i=1;i<=cols;i++){
					data1[count][i-1]=rs.getString(i);
				}
				count++;
			}
			con.close();
		}catch(Exception e){System.out.println(e);
		}
		
		table1 = new JTable(data1,column1);
		table1.setBackground(new Color(0, 0, 0, 0));
		table1.setShowVerticalLines(false);
		table1.setForeground(new Color(0, 0, 51));
		table1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table1.setGridColor(new Color(0, 0, 0));
		table1.setBorder(null);
		table1.setOpaque(false);
		table1.getColumnModel().getColumn(0).setPreferredWidth(100);
		table1.getColumnModel().getColumn(0).setMaxWidth(100);
		table1.getColumnModel().getColumn(1).setPreferredWidth(450);
		table1.getColumnModel().getColumn(1).setMaxWidth(450);
		table1.getColumnModel().getColumn(2).setPreferredWidth(200);
		table1.getColumnModel().getColumn(2).setMaxWidth(200);
		table1.getColumnModel().getColumn(3).setPreferredWidth(200);
		table1.getColumnModel().getColumn(3).setMaxWidth(200);
		table1.getColumnModel().getColumn(4).setPreferredWidth(100);
		table1.getColumnModel().getColumn(4).setMaxWidth(100);
		table1.getColumnModel().getColumn(5).setPreferredWidth(100);
		table1.getColumnModel().getColumn(5).setMaxWidth(100);
		table1.getColumnModel().getColumn(6).setPreferredWidth(233);
		table1.getColumnModel().getColumn(6).setMaxWidth(233);
		table1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table1.setRowHeight(25);
		table1.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		
		JScrollPane sp1=new JScrollPane(table1);
		sp1.setSize(1386, 750);
		sp1.setLocation(32, 276);
		sp1.setViewportBorder(null);
		sp1.setBorder(null);
		sp1.setOpaque(false);
		sp1.getViewport().setOpaque(false);
		desktopPane1.add(sp1);
		
		//add book panel
		JPanel panel1 = new JPanel();
		panel1.setBackground(new Color(0, 0, 0, 0));
		panel1.setBounds(256, 30, 1186, 219);
		desktopPane1.add(panel1);
		panel1.setLayout(null);
		
		JLabel lblCallNo1 = new JLabel("Book ID:");
		lblCallNo1.setBounds(10, 23, 109, 18);
		panel1.add(lblCallNo1);
		lblCallNo1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCallNo1.setForeground(new Color(0, 0, 51));
		lblCallNo1.setFont(new Font("Century Gothic", Font.BOLD, 18));
		
		JTextField textFieldcallno1 = new JTextField();
		textFieldcallno1.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textFieldcallno1.setBounds(129, 21, 304, 26);
		panel1.add(textFieldcallno1);
		textFieldcallno1.setColumns(10);
		
		JLabel lblTitle1 = new JLabel("Title:");
		lblTitle1.setBounds(10, 70, 109, 18);
		panel1.add(lblTitle1);
		lblTitle1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTitle1.setForeground(new Color(0, 0, 51));
		lblTitle1.setFont(new Font("Century Gothic", Font.BOLD, 18));
		
		JTextField textFieldtitle1 = new JTextField();
		textFieldtitle1.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textFieldtitle1.setBounds(129, 68, 304, 26);
		panel1.add(textFieldtitle1);
		textFieldtitle1.setColumns(10);
		
		JTextField textFieldauthor1 = new JTextField();
		textFieldauthor1.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textFieldauthor1.setBounds(129, 121, 304, 26);
		panel1.add(textFieldauthor1);
		textFieldauthor1.setColumns(10);
		
		JLabel lblAuthor1 = new JLabel("Author:");
		lblAuthor1.setBounds(10, 123, 109, 18);
		panel1.add(lblAuthor1);
		lblAuthor1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblAuthor1.setForeground(new Color(0, 0, 51));
		lblAuthor1.setFont(new Font("Century Gothic", Font.BOLD, 18));
		
		JTextField textField_3 = new JTextField();
		textField_3.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textField_3.setBounds(618, 21, 304, 26);
		panel1.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblPublisher = new JLabel("Publisher:");
		lblPublisher.setBounds(499, 23, 109, 18);
		panel1.add(lblPublisher);
		lblPublisher.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPublisher.setForeground(new Color(255, 255, 255));
		lblPublisher.setFont(new Font("Century Gothic", Font.BOLD, 18));
		
		JLabel lblQuantity1 = new JLabel("Quantity:");
		lblQuantity1.setBounds(499, 70, 109, 23);
		panel1.add(lblQuantity1);
		lblQuantity1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblQuantity1.setForeground(new Color(255, 255, 255));
		lblQuantity1.setFont(new Font("Century Gothic", Font.BOLD, 18));
		
		JTextField textField_4 = new JTextField();
		textField_4.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textField_4.setBounds(618, 68, 304, 26);
		panel1.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnaddbook1 = new JButton("Add Books");
		btnaddbook1.setBounds(10, 30, 236, 98);
		desktopPane1.add(btnaddbook1);
		btnaddbook1.setForeground(new Color(255, 255, 255));
		btnaddbook1.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(255, 255, 255), new Color(255, 255, 255), new Color(255, 255, 255), new Color(255, 255, 255)));
		btnaddbook1.setBackground(new Color(0, 0, 51));
		btnaddbook1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnaddbook1.setFont(new Font("Century Gothic", Font.PLAIN, 20));
		
		JButton btnNewButton_1_1 = new JButton("Delete Book");
		btnNewButton_1_1.setBounds(10, 151, 236, 98);
		desktopPane1.add(btnNewButton_1_1);
		btnNewButton_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1.setFont(new Font("Century Gothic", Font.PLAIN, 20));
		btnNewButton_1_1.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(255, 255, 255), new Color(255, 255, 255), new Color(255, 255, 255), new Color(255, 255, 255)));
		btnNewButton_1_1.setBackground(new Color(0, 0, 51));
		
		JButton btnAddBooks = new JButton("Add Book");
		btnAddBooks.setBounds(618, 117, 136, 30);
		panel1.add(btnAddBooks);
		btnAddBooks.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnAddBooks.setForeground(new Color(255, 255, 255));
		btnAddBooks.setBackground(new Color(0, 0, 51));
		btnAddBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String callno=textFieldcallno1.getText();
			String name=textFieldtitle1.getText();
			String author=textFieldauthor1.getText();
			String publisher=textField_3.getText();
			String squantity=textField_4.getText();
			int quantity=Integer.parseInt(squantity);
			int i=BookDao.save(callno, name, author, publisher, quantity);
			if(i>00){
				JOptionPane.showMessageDialog(LibrarianSuccess.this,"Book added successfully!");
				textFieldcallno1.setText("");
				textFieldtitle1.setText("");
				textFieldauthor1.setText("");
				textField_3.setText("");
				textField_4.setText("");
			}else{
				JOptionPane.showMessageDialog(LibrarianSuccess.this,"Sorry, unable to save!");
			}
			refreshTablebooks();
			
			// Select the newly added row in the JTable
            int rowIndex = table1.getRowCount() - 1;
            table1.setRowSelectionInterval(rowIndex, rowIndex);

            // Scroll to the newly added row
            table1.scrollRectToVisible(table1.getCellRect(rowIndex, 0, true));
			}
		});
		
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(new Color(0, 0, 0, 0));
		panel2.setBounds(256, 30, 1186, 219);
		desktopPane1.add(panel2);
		panel2.setLayout(null);
		panel2.setVisible(false);
		
		JLabel lblName2 = new JLabel("Book ID:");
		lblName2.setBackground(new Color(255, 255, 255));
		lblName2.setBounds(24, 36, 122, 24);
		panel2.add(lblName2);
		lblName2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblName2.setForeground(new Color(0, 0, 51));
		lblName2.setFont(new Font("Century Gothic", Font.BOLD, 18));
		
		JTextField textField2 = new JTextField();
		textField2.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textField2.setBounds(156, 39, 271, 26);
		panel2.add(textField2);
		textField2.setColumns(10);	
		
		JButton btnNewButton2 = new JButton("Delete");
		btnNewButton2.setBounds(226, 97, 136, 30);
		btnNewButton2.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnNewButton2.setForeground(new Color(255, 255, 255));
		btnNewButton2.setBackground(new Color(0, 0, 51));
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String scn=textField2.getText();
				if(scn==null||scn.trim().equals("")){
					JOptionPane.showMessageDialog(LibrarianSuccess.this,"Book ID can't be blank");
				}else{
					String callno=(scn);
					int i=BookDao.delete(callno);
					if(i>0){
						JOptionPane.showMessageDialog(LibrarianSuccess.this,"Record deleted successfully!");
						textField2.setText("");
					}else{
						JOptionPane.showMessageDialog(LibrarianSuccess.this,"Unable to delete given Book ID!");
					}
				}
				refreshTablebooks();
			}
		});
		panel2.add(btnNewButton2);
		
		btnNewButton_1_1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				panel1.setVisible(false);
				panel2.setVisible(true);
				
			}
		});
		btnaddbook1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel1.setVisible(true);
				panel2.setVisible(false);
			}
		});
		
		JLabel lblNewLabel_231 = new JLabel(image);
		lblNewLabel_231.setBounds(1070, -102, 500, 493);
		desktopPane1.add(lblNewLabel_231);
		
		JLabel lblNewLabel_72 = new JLabel(image1);
		lblNewLabel_72.setBounds(231, 0, 1361, 1114);
		desktopPane1.add(lblNewLabel_72);
		
		//history pane
		JDesktopPane desktopPane4 = new JDesktopPane();
		desktopPane4.setBackground(new Color(255, 255, 255));
		desktopPane4.setBounds(456, 9, 1458, 1050);
		contentPane.add(desktopPane4);
		desktopPane4.setVisible(false);
		
		//table for history
		String data4[][]=null;
		String column4[]=null;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from history",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			
			ResultSetMetaData rsmd=rs.getMetaData();
			int cols=rsmd.getColumnCount();
			column4=new String[cols];
			for(int i=1;i<=cols;i++){
				column4[i-1]=rsmd.getColumnName(i);
			}
			
			rs.last();
			int rows=rs.getRow();
			rs.beforeFirst();

			data4=new String[rows][cols];
			int count=0;
			while(rs.next()){
				for(int i=1;i<=cols;i++){
					data4[count][i-1]=rs.getString(i);
				}
				count++;
			}
			con.close();
		}catch(Exception e){System.out.println(e);}
		
		table4 = new JTable(data4,column4);
		table4.setBackground(new Color(0, 0, 0, 0));
		table4.setShowVerticalLines(false);
		table4.setForeground(new Color(0, 0, 51));
		table4.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table4.setGridColor(new Color(0, 0, 0));
		table4.setBorder(null);
		table4.setOpaque(false);
		table4.getColumnModel().getColumn(0).setPreferredWidth(100);
		table4.getColumnModel().getColumn(0).setMaxWidth(100);
		table4.getColumnModel().getColumn(1).setPreferredWidth(150);
		table4.getColumnModel().getColumn(1).setMaxWidth(150);
		table4.getColumnModel().getColumn(2).setPreferredWidth(500);
		table4.getColumnModel().getColumn(2).setMaxWidth(500);
		table4.getColumnModel().getColumn(3).setPreferredWidth(150);
		table4.getColumnModel().getColumn(3).setMaxWidth(150);
		table4.getColumnModel().getColumn(4).setPreferredWidth(300);
		table4.getColumnModel().getColumn(4).setMaxWidth(300);
		table4.getColumnModel().getColumn(5).setPreferredWidth(170);
		table4.getColumnModel().getColumn(5).setMaxWidth(170);
		table4.getColumnModel().getColumn(6).setPreferredWidth(150);
		table4.getColumnModel().getColumn(6).setMaxWidth(150);
		table4.getColumnModel().getColumn(7).setPreferredWidth(150);
		table4.getColumnModel().getColumn(7).setMaxWidth(150);
		table4.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table4.setRowHeight(25);
		table4.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		
		JScrollPane sp4 =new JScrollPane(table4);
		sp4.setSize(1438, 1025);
		sp4.setLocation(10, 11);
		sp4.setViewportBorder(null);
		sp4.setBorder(null);
		sp4.getViewport().setOpaque(false);
		desktopPane4.add(sp4);
		
		JLabel lblNewLabel_74 = new JLabel(image1);
		lblNewLabel_74.setBounds(231, 0, 1361, 1114);
		desktopPane4.add(lblNewLabel_74);
						

		
		//add, edit and delete student
		JDesktopPane desktopPane3 = new JDesktopPane();
		desktopPane3.setBackground(new Color(255, 255, 255));
		desktopPane3.setBounds(456, 9, 1458, 1050);
		contentPane.add(desktopPane3);
		desktopPane3.setVisible(false);
		
		JLabel lblNewLabel35 = new JLabel("Search:");
		lblNewLabel35.setForeground(new Color(0,0,51));
		lblNewLabel35.setFont(new Font("Century Gothic", Font.BOLD, 20));
		lblNewLabel35.setBounds(839, 227, 74, 27);
		desktopPane3.add(lblNewLabel35);
		
		//student search field
		JTextField textField_8 = new JTextField();
		textField_8.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textField_8.setFont(new Font("Century Gothic", Font.PLAIN, 16));
		textField_8.setBounds(923, 228, 233, 27);
		desktopPane3.add(textField_8);
		textField_8.setColumns(10);
		textField_8.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				TableModel model3=(TableModel)table3.getModel();
				String search3= textField_8.getText();
				TableRowSorter<TableModel>tr3= new TableRowSorter<TableModel>(model3);
				table3.setRowSorter(tr3);
				tr3.setRowFilter(RowFilter.regexFilter(search3));
			}
		});
		
	
		String data3[][]=null;
		String column3[]=null;
		try{ 
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from student",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			
			ResultSetMetaData rsmd=rs.getMetaData();
			int cols=rsmd.getColumnCount();
			column3=new String[cols];
			for(int i=1;i<=cols;i++){
				column3[i-1]=rsmd.getColumnName(i);
			}
			
			rs.last();
			int rows3=rs.getRow();
			rs.beforeFirst();

			data3=new String[rows3][cols];
			int count=0;
			while(rs.next()){
				for(int i=1;i<=cols;i++){
					data3[count][i-1]=rs.getString(i);
				}
				count++;
			}
			con.close();
		}catch(Exception e){System.out.println(e);
		}
		
		table3 = new JTable(data3,column3);
		table3.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		table3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		table3.setRowHeight(25);
		table3.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		table3.setShowVerticalLines(false);
		table3.setForeground(new Color(0, 0, 51));
		table3.setGridColor(new Color(0, 0, 0));
		table3.setBorder(null);
		table3.setOpaque(false);
		table3.setBackground(new Color(0, 0, 0, 0));
		table3.getColumnModel().getColumn(0).setPreferredWidth(70);
		table3.getColumnModel().getColumn(0).setMaxWidth(70);
		table3.getColumnModel().getColumn(1).setPreferredWidth(200);
		table3.getColumnModel().getColumn(1).setMaxWidth(200);
		table3.getColumnModel().getColumn(2).setPreferredWidth(500);
		table3.getColumnModel().getColumn(2).setMaxWidth(500);
		table3.getColumnModel().getColumn(3).setPreferredWidth(130);
		table3.getColumnModel().getColumn(3).setMaxWidth(130);
		table3.getColumnModel().getColumn(4).setPreferredWidth(200);
		table3.getColumnModel().getColumn(4).setMaxWidth(200);
		table3.getColumnModel().getColumn(5).setPreferredWidth(282);
		table3.getColumnModel().getColumn(5).setMaxWidth(282);
		table3.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
		JScrollPane sp3=new JScrollPane(table3);
		sp3.setSize(1386, 750);
		sp3.setLocation(32, 276);
		sp3.setViewportBorder(null);
		sp3.setBorder(null);
		sp3.setOpaque(false);
		sp3.getViewport().setOpaque(false);
		desktopPane3.add(sp3);
		
		//add student
		JPanel panel3 = new JPanel();
		panel3.setBackground(new Color(0, 0, 0, 0));
		panel3.setBounds(256, 30, 1186, 219);
		desktopPane3.add(panel3);
		panel3.setLayout(null);
		
		JLabel lblName = new JLabel("Student ID:");
		lblName.setBounds(24, 17, 104, 19);
		panel3.add(lblName);
		lblName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblName.setForeground(new Color(0, 0, 51));
		lblName.setFont(new Font("Century Gothic", Font.BOLD, 15));
		
		JTextField textField = new JTextField();
		textField.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textField.setBounds(169, 18, 180, 20);
		panel3.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("* Student Information");
		lblNewLabel_3.setBounds(10, 49, 206, 24);
		panel3.add(lblNewLabel_3);
		lblNewLabel_3.setForeground(new Color(0, 51, 255));
		lblNewLabel_3.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		
		JLabel lblPassword = new JLabel("Student's Name:");
		lblPassword.setBounds(10, 84, 136, 18);
		panel3.add(lblPassword);
		lblPassword.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPassword.setForeground(new Color(0, 0, 51));
		lblPassword.setFont(new Font("Century Gothic", Font.BOLD, 15));
		
		JTextField textField_7 = new JTextField();
		textField_7.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textField_7.setBounds(169, 82, 591, 20);
		panel3.add(textField_7);
		textField_7.setColumns(10);
		
		JLabel lblCity = new JLabel("Strand:");
		lblCity.setBounds(37, 114, 109, 18);
		panel3.add(lblCity);
		lblCity.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCity.setForeground(new Color(0, 0, 51));
		lblCity.setFont(new Font("Century Gothic", Font.BOLD, 15));
		
		JLabel lblContactNo = new JLabel("Grade & Section:");
		lblContactNo.setBounds(-11, 143, 157, 18);
		panel3.add(lblContactNo);
		lblContactNo.setHorizontalAlignment(SwingConstants.RIGHT);
		lblContactNo.setForeground(new Color(0, 0, 51));
		lblContactNo.setFont(new Font("Century Gothic", Font.BOLD, 15));
		
		JLabel lblContactNo_1 = new JLabel("Contact No:");
		lblContactNo_1.setBounds(379, 114, 109, 18);
		panel3.add(lblContactNo_1);
		lblContactNo_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblContactNo_1.setForeground(new Color(255, 255, 255));
		lblContactNo_1.setFont(new Font("Century Gothic", Font.BOLD, 15));
		
		JTextField textField_5 = new JTextField();
		textField_5.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textField_5.setBounds(498, 112, 262, 20);
		panel3.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton = new JButton("Add Student");
		btnNewButton.setBounds(428, 178, 136, 30);
		panel3.add(btnNewButton);
		btnNewButton.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(0, 0, 51));
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			 @Override
	            public void actionPerformed(ActionEvent e) {
	                updateSecondComboBox(); 			
	        }
		});
		comboBox.setForeground(new Color(255, 255, 255));
		comboBox.setBackground(new Color(0, 0, 51));
		comboBox.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"ABM", "HUMSS", "ICT"}));
		comboBox.setBounds(169, 113, 96, 24);
		panel3.add(comboBox);
		
		defaultSecondComboBoxModel = new DefaultComboBoxModel<>();
		comboBox_1 = new JComboBox(defaultSecondComboBoxModel);
		comboBox_1.setMaximumRowCount(30);
		comboBox_1.setForeground(Color.WHITE);
		comboBox_1.setFont(new Font("Century Gothic", Font.PLAIN, 15));
		comboBox_1.setBackground(new Color(0, 0, 51));
		comboBox_1.setBounds(169, 143, 136, 24);
		panel3.add(comboBox_1);
		
		JLabel lblNo = new JLabel("No.:");
		lblNo.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNo.setForeground(new Color(255, 255, 255));
		lblNo.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lblNo.setBounds(384, 17, 104, 19);
		panel3.add(lblNo);
		
		JTextField textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setFont(new Font("Century Gothic", Font.PLAIN, 11));
		textField_1.setColumns(10);
		textField_1.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textField_1.setBounds(498, 18, 50, 20);
		panel3.add(textField_1);
		
		//delete student
		JPanel panel3_2 = new JPanel();
		panel3_2.setBackground(new Color(0, 0,0,0));
		panel3_2.setBounds(256, 30, 1186, 219);
		desktopPane3.add(panel3_2);
		panel3_2.setLayout(null);
		panel3_2.setVisible(false);
		
		JLabel lblName4 = new JLabel("Student ID:");
		lblName4.setForeground(new Color(0, 0, 51));
		lblName4.setFont(new Font("Century Gothic", Font.BOLD, 18));
		lblName4.setBounds(42, 41, 104, 24);
		panel3_2.add(lblName4);
		
		JTextField textField24 = new JTextField();
		textField24.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		textField24.setBounds(156, 39, 271, 26);
		panel3_2.add(textField24);
		textField24.setColumns(10);
		
		JButton btnNewButton24 = new JButton("Delete");
		btnNewButton24.setBounds(226, 97, 136, 30);
		panel3_2.add(btnNewButton24);
		btnNewButton24.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btnNewButton24.setForeground(new Color(255, 255, 255));
		btnNewButton24.setBackground(new Color(0, 0, 51));
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String LRN=textField.getText();
			String LastName=textField_7.getText();
			Object Strand=comboBox.getSelectedItem();
			Object GradeAndSection=comboBox_1.getSelectedItem();
			String Contact=textField_5.getText();
			
			
			
			int i=StudentDao.save(LRN, LastName, Strand, GradeAndSection, Contact);
			if(i>0){
				JOptionPane.showMessageDialog(LibrarianSuccess.this,"Student added successfully!");
				textField_1.setText("");
				textField.setText("");
				textField_7.setText("");
				textField_5.setText("");
				
			}else{
				JOptionPane.showMessageDialog(LibrarianSuccess.this,"Sorry, unable to save!");
			}
			refreshTablestudent();
			
			// Select the newly added row in the JTable
            int rowIndex = table3.getRowCount() - 1;
            table3.setRowSelectionInterval(rowIndex, rowIndex);

            // Scroll to the newly added row
            table3.scrollRectToVisible(table3.getCellRect(rowIndex, 0, true));
			}
		
		});
		
		btnNewButton24.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String slrn=textField24.getText();
				if(slrn==null||slrn.trim().equals("")){
					JOptionPane.showMessageDialog(LibrarianSuccess.this,"Student ID can't be blank");
				}else{
					String LRN=(slrn);
					int i=StudentDao.delete(LRN);
					if(i>0){
						JOptionPane.showMessageDialog(LibrarianSuccess.this,"Record deleted successfully!");
						textField24.setText("");
						
					}else{
						JOptionPane.showMessageDialog(LibrarianSuccess.this,"Unable to delete given Student ID!");
					}
				}
				refreshTablestudent();
			}

		
		});
		
		JButton btnNewButton_1 = new JButton("Add Student");
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(255, 255, 255), new Color(255, 255, 255), new Color(255, 255, 255), new Color(255, 255, 255)));
		btnNewButton_1.setBackground(new Color(0, 0, 51));
		btnNewButton_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton_1.setFont(new Font("Century Gothic", Font.PLAIN, 20));
		btnNewButton_1.setBounds(10, 30, 236, 98);
		desktopPane3.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel3.setVisible(true);
				panel3_2.setVisible(false);
			}
		});
		
		table3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					int column = 0;
					int row = table3.getSelectedRow();
					String tblno = table3.getModel().getValueAt(row, column).toString();
			
					int column1 = 1;
					int row1 = table3.getSelectedRow();
					String tblLRN = table3.getModel().getValueAt(row1, column1).toString();
			
					int column2 = 2;
					int row2 = table3.getSelectedRow();
					String tblLastName = table3.getModel().getValueAt(row2, column2).toString();
			
					int column3 = 3;
					int row3 = table3.getSelectedRow();
					String tblStrand = table3.getModel().getValueAt(row3, column3).toString();
			
					int column4 = 4;
					int row4 = table3.getSelectedRow();
					String tblGradeAndSection = table3.getModel().getValueAt(row4, column4).toString();
			
					int column5 = 5;
					int row5 = table3.getSelectedRow();
					String tblContact = table3.getModel().getValueAt(row5, column5).toString();
					
				JButton btnNewButton25 = new JButton("Edit");
				btnNewButton25.setBounds(80, 178, 136, 30);
				panel3.add(btnNewButton25);
				btnNewButton25.setFont(new Font("Century Gothic", Font.BOLD, 15));
				btnNewButton25.setForeground(new Color(255, 255, 255));
				btnNewButton25.setBackground(new Color(0, 0, 51));
				btnNewButton25.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						textField_1.setText(tblno);
						textField.setText(tblLRN);
						textField_7.setText(tblLastName);
						comboBox.setSelectedItem(tblStrand);
						comboBox_1.setSelectedItem(tblGradeAndSection);
						textField_5.setText(tblContact);
						
						table3.addMouseListener(new MouseAdapter() {
							public void mouseClicked(MouseEvent e) {
								try {
								int column = 0;
								int row = table3.getSelectedRow();
								String tblno1 = table3.getModel().getValueAt(row, column).toString();
						
								int column1 = 1;
								int row1 = table3.getSelectedRow();
								String tblLRN1 = table3.getModel().getValueAt(row1, column1).toString();
						
								int column2 = 2;
								int row2 = table3.getSelectedRow();
								String tblLastName1 = table3.getModel().getValueAt(row2, column2).toString();
						
								int column3 = 3;
								int row3 = table3.getSelectedRow();
								String tblStrand1 = table3.getModel().getValueAt(row3, column3).toString();
						
								int column4 = 4;
								int row4 = table3.getSelectedRow();
								String tblGradeAndSection1 = table3.getModel().getValueAt(row4, column4).toString();
						
								int column5 = 5;
								int row5 = table3.getSelectedRow();
								String tblContact1 = table3.getModel().getValueAt(row5, column5).toString();
								
								textField_1.setText(tblno1);
								textField.setText(tblLRN1);
								textField_7.setText(tblLastName1);
								comboBox.setSelectedItem(tblStrand1);
								comboBox_1.setSelectedItem(tblGradeAndSection1);
								textField_5.setText(tblContact1);
	
							}catch(Exception e1){
									System.out.println(e1);
								}
								return;
							}
						});
						
						JButton btnNewButton251 = new JButton("Update");
						btnNewButton251.setBounds(253, 178, 136, 30);
						panel3.add(btnNewButton251);
						btnNewButton251.setFont(new Font("Century Gothic", Font.BOLD, 15));
						btnNewButton251.setForeground(new Color(255, 255, 255));
						btnNewButton251.setBackground(new Color(0, 0, 51));
						btnNewButton251.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								String no=textField_1.getText();
								String LRN=textField.getText();
								String LastName=textField_7.getText();
								Object Strand=comboBox.getSelectedItem();
								Object GradeAndSection=comboBox_1.getSelectedItem();
								String Contact=textField_5.getText();
								
								
								int i=StudentDao.update(no, LRN, LastName, Strand, GradeAndSection, Contact);
								if(i>0){
									JOptionPane.showMessageDialog(LibrarianSuccess.this,"Record updated successfully!");
									textField_1.setText("");
									textField.setText("");
									textField_7.setText("");
									textField_5.setText("");
	
									
									btnNewButton251.setVisible(false);
									btnNewButton25.setVisible(false);	
									
								}else{
									JOptionPane.showMessageDialog(LibrarianSuccess.this,"Unable to update!");
									
									}
								refreshTablestudent();
						}
					});
						}
					});
					}catch(Exception e1){
							System.out.println(e1);
						}
						
						return;
					}
				});
					
		JButton btnNewButton_1_2 = new JButton("Delete Student");
		btnNewButton_1_2.setForeground(Color.WHITE);
		btnNewButton_1_2.setFont(new Font("Century Gothic", Font.PLAIN, 20));
		btnNewButton_1_2.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(255, 255, 255), new Color(255, 255, 255), new Color(255, 255, 255), new Color(255, 255, 255)));
		btnNewButton_1_2.setBackground(new Color(0, 0, 51));
		btnNewButton_1_2.setBounds(10, 151, 236, 98);
		desktopPane3.add(btnNewButton_1_2);
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel3.setVisible(false);
				panel3_2.setVisible(true);
			}
		});
		
		
		JLabel lblNewLabel_2313 = new JLabel(image);
		lblNewLabel_2313.setBounds(1070, -102, 500, 493);
		desktopPane3.add(lblNewLabel_2313);
		
		JLabel lblNewLabel_723= new JLabel(image1);
		lblNewLabel_723.setBounds(231, 0, 1361, 1114);
		desktopPane3.add(lblNewLabel_723);
		
		//navigation
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 51));
		panel.setBounds(0, 0, 446, 1080);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lbllib_1 = new JLabel("Library Management System");
		lbllib_1.setHorizontalAlignment(SwingConstants.CENTER);
		lbllib_1.setForeground(SystemColor.textHighlightText);
		lbllib_1.setFont(new Font("Franklin Gothic Demi Cond", Font.PLAIN, 22));
		lbllib_1.setBounds(148, 109, 288, 38);
		panel.add(lbllib_1);
		
		JButton btnLogout = new JButton(" Logout");
		btnLogout.setIcon(image10);
		btnLogout.setOpaque(false);
		btnLogout.setForeground(new Color(255, 255, 255));
		btnLogout.setBorder(null);
		btnLogout.setBackground(new Color(51, 102, 153));
		btnLogout.setBounds(10, 1016, 150, 53);
		panel.add(btnLogout);
		btnLogout.setFont(new Font("Century Gothic", Font.ITALIC, 25));
		
		JButton btnReturnBook = new JButton("  Return Book");
		btnReturnBook.setIcon(image9);
		btnReturnBook.setOpaque(false);
		btnReturnBook.setHorizontalAlignment(SwingConstants.LEFT);
		btnReturnBook.setForeground(new Color(255, 255, 255));
		btnReturnBook.setBorder(null);
		btnReturnBook.setBackground(new Color(51, 102, 153));
		btnReturnBook.setBounds(0, 653, 446, 50);
		panel.add(btnReturnBook);
		btnReturnBook.setFont(new Font("Century Gothic", Font.BOLD, 30));
		
		JButton btnViewIssuedBooks = new JButton("  History");
		btnViewIssuedBooks.setIcon(image6);
		btnViewIssuedBooks.setOpaque(false);
		btnViewIssuedBooks.setHorizontalAlignment(SwingConstants.LEFT);
		btnViewIssuedBooks.setBackground(new Color(51, 102, 153));
		btnViewIssuedBooks.setBorder(null);
		btnViewIssuedBooks.setForeground(new Color(255, 255, 255));
		btnViewIssuedBooks.setBounds(0, 453, 446, 50);
		panel.add(btnViewIssuedBooks);
		btnViewIssuedBooks.setFont(new Font("Century Gothic", Font.BOLD, 30));
		
		JButton btnViewBooks = new JButton("  Accession List");
		btnViewBooks.setIcon(image5);
		btnViewBooks.setOpaque(false);
		btnViewBooks.setHorizontalAlignment(SwingConstants.LEFT);
		btnViewBooks.setForeground(new Color(255, 255, 255));
		btnViewBooks.setBackground(new Color(51, 102, 153));
		btnViewBooks.setBorder(null);
		btnViewBooks.setBounds(0, 353, 446, 50);
		panel.add(btnViewBooks);
		btnViewBooks.setFont(new Font("Century Gothic", Font.BOLD, 30));
		
		JLabel lbllib = new JLabel("AutoLib");
		lbllib.setHorizontalAlignment(SwingConstants.RIGHT);
		lbllib.setForeground(SystemColor.textHighlightText);
		lbllib.setFont(new Font("Algerian", Font.PLAIN, 70));
		lbllib.setBounds(10, 59, 426, 76);
		panel.add(lbllib);
		
		
		JLabel lblManagementSystem = new JLabel("");
		lblManagementSystem.setIcon(image11);
		lblManagementSystem.setForeground(Color.WHITE);
		lblManagementSystem.setFont(new Font("Bookman Old Style", Font.PLAIN, 30));
		lblManagementSystem.setBounds(-20, 25, 222, 168);
		panel.add(lblManagementSystem);
		
		JButton btnViewStudentList = new JButton("  Student List");
		btnViewStudentList.setIcon(image0);
		btnViewStudentList.setOpaque(false);
		btnViewStudentList.setHorizontalAlignment(SwingConstants.LEFT);
		btnViewStudentList.setForeground(Color.WHITE);
		btnViewStudentList.setFont(new Font("Century Gothic", Font.BOLD, 30));
		btnViewStudentList.setBorder(null);
		btnViewStudentList.setBackground(new Color(51, 102, 153));
		btnViewStudentList.setBounds(0, 753, 446, 50);
		panel.add(btnViewStudentList);
	
		JButton btnLogSheet = new JButton("  Log Sheet");
		btnLogSheet.setIcon(image8);
		btnLogSheet.setOpaque(false);
		btnLogSheet.setHorizontalAlignment(SwingConstants.LEFT);
		btnLogSheet.setForeground(Color.WHITE);
		btnLogSheet.setFont(new Font("Century Gothic", Font.BOLD, 30));
		btnLogSheet.setBorder(null);
		btnLogSheet.setBackground(new Color(51, 102, 153));
		btnLogSheet.setBounds(0, 253, 446, 50);
		panel.add(btnLogSheet);
		
		
		JButton btnIssueBook = new JButton("  Issue Book");
		btnIssueBook.setIcon(image7);
		btnIssueBook.setOpaque(false);
		btnIssueBook.setHorizontalAlignment(SwingConstants.LEFT);
		btnIssueBook.setForeground(Color.WHITE);
		btnIssueBook.setFont(new Font("Century Gothic", Font.BOLD, 30));
		btnIssueBook.setBorder(null);
		btnIssueBook.setBackground(new Color(51, 102, 153));
		btnIssueBook.setBounds(0, 553, 446, 50);
		panel.add(btnIssueBook);
		
		ImageIcon image2= new ImageIcon(getClass().getResource("borders1.png"));
		
		JLabel lblNewLabel_6 = new JLabel(image2);
		lblNewLabel_6.setBounds(0, -30, 847, 930);
		panel.add(lblNewLabel_6);
		
		
		
		//codes
		
		btnNewButton_2_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				desktopPane1.setVisible(false);
				desktopPane2.setVisible(true);
				desktopPane3.setVisible(false);
				desktopPane4.setVisible(false);
				desktopPane5.setVisible(false);
				
				btnLogSheet.setOpaque(true);
				btnReturnBook.setOpaque(false);
				btnViewIssuedBooks.setOpaque(false);
				btnViewBooks.setOpaque(false);
				btnViewStudentList.setOpaque(false);
				btnIssueBook.setOpaque(false);
			}
		});
		
				btnLogout.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(JOptionPane.showConfirmDialog(LibrarianSuccess.this,"Do you want to Log Out?", getTitle(), JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
							System.exit(0);
						}else{
							
						}
					}
				});
				
				btnReturnBook.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						ReturnBook.main(new String[]{});
						
						btnLogSheet.setOpaque(false);
						btnReturnBook.setOpaque(true);
						btnViewIssuedBooks.setOpaque(false);
						btnViewBooks.setOpaque(false);
						btnViewStudentList.setOpaque(false);
						btnIssueBook.setOpaque(false);
					}
				});
				
				btnViewIssuedBooks.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						desktopPane4.setVisible(true);
						desktopPane1.setVisible(false);
						desktopPane2.setVisible(false); 
						desktopPane3.setVisible(false);
						desktopPane5.setVisible(false);
						
						btnLogSheet.setOpaque(false);
						btnReturnBook.setOpaque(false);
						btnViewIssuedBooks.setOpaque(true);
						btnViewBooks.setOpaque(false);
						btnViewStudentList.setOpaque(false);
						btnIssueBook.setOpaque(false);
					}
				});
				
				btnViewBooks.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						desktopPane1.setVisible(true);
						desktopPane2.setVisible(false); 
						desktopPane3.setVisible(false);
						desktopPane4.setVisible(false);
						desktopPane5.setVisible(false);
						
						btnLogSheet.setOpaque(false);
						btnReturnBook.setOpaque(false);
						btnViewIssuedBooks.setOpaque(false);
						btnViewBooks.setOpaque(true);
						btnViewStudentList.setOpaque(false);
						btnIssueBook.setOpaque(false);
					}
				});
				
				btnViewStudentList.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						desktopPane1.setVisible(false);
						desktopPane2.setVisible(false);
						desktopPane3.setVisible(true);
						desktopPane4.setVisible(false);
						desktopPane5.setVisible(false);
						
						btnLogSheet.setOpaque(false);
						btnReturnBook.setOpaque(false);
						btnViewIssuedBooks.setOpaque(false);
						btnViewBooks.setOpaque(false);
						btnViewStudentList.setOpaque(true);
						btnIssueBook.setOpaque(false);
					}
				});
				
				btnLogSheet.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						desktopPane1.setVisible(false);
						desktopPane2.setVisible(true);
						desktopPane3.setVisible(false);
						desktopPane4.setVisible(false);
						desktopPane5.setVisible(false);
						
						btnLogSheet.setOpaque(true);
						btnReturnBook.setOpaque(false);
						btnViewIssuedBooks.setOpaque(false);
						btnViewBooks.setOpaque(false);
						btnViewStudentList.setOpaque(false);
						btnIssueBook.setOpaque(false);
						}
				});
				
				btnIssueBook.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						IssueBooks.main(new String[]{});
						
						btnLogSheet.setOpaque(false);
						btnReturnBook.setOpaque(false);
						btnViewIssuedBooks.setOpaque(false);
						btnViewBooks.setOpaque(false);
						btnViewStudentList.setOpaque(false);
						btnIssueBook.setOpaque(true);
					}
				});
				
				//label code
				lbllib.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						LibrarianSuccess.main(new String[]{});
						frame1.dispose();
					}
				});
				
	}
	protected void updateSecondComboBox() {
		defaultSecondComboBoxModel.removeAllElements(); // Clear previous items

        // Add items to the second ComboBox based on the selection in the first ComboBox
        String selectedItem = (String) comboBox.getSelectedItem();
        if (selectedItem.equals("ABM")) {
            defaultSecondComboBoxModel.addElement("12 - Pacioli");
            defaultSecondComboBoxModel.addElement("12 - Valix");
            defaultSecondComboBoxModel.addElement("12 - Marx");
        } else if (selectedItem.equals("HUMSS")) {
            defaultSecondComboBoxModel.addElement("12 - Aristotle");
            defaultSecondComboBoxModel.addElement("12 - Socrates");
            defaultSecondComboBoxModel.addElement("12 - Plato");
            defaultSecondComboBoxModel.addElement("12 - Locke");
            defaultSecondComboBoxModel.addElement("12 - Confucius");
        } else if (selectedItem.equals("ICT")) {
            defaultSecondComboBoxModel.addElement("12 - Jobs");
            defaultSecondComboBoxModel.addElement("12 - Gates");
            defaultSecondComboBoxModel.addElement("12 - Roberts");
            defaultSecondComboBoxModel.addElement("12 - Dell");

        }
    }
	
}
